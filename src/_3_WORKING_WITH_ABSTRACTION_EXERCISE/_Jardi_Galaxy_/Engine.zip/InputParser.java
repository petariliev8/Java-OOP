package _3_WORKING_WITH_ABSTRACTION_EXERCISE._Jardi_Galaxy_;

import java.util.Arrays;

public class InputParser {
    public static int[] parseIntegerArray(String input) {
        return Arrays
                .stream(input.split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();
    }
}
