package _3_WORKING_WITH_ABSTRACTION_EXERCISE;

import _3_WORKING_WITH_ABSTRACTION_EXERCISE._1_CardSuit.CardSuit;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Card Suits:");

        for (CardSuit value : CardSuit.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n"
                    ,value.ordinal(), value);
        }

    }
}
