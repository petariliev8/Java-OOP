package _3_WORKING_WITH_ABSTRACTION_EXERCISE._1_CardSuit;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES

}
