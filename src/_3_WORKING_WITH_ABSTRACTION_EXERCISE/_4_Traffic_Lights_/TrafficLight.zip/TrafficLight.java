package _3_WORKING_WITH_ABSTRACTION_EXERCISE._4_Traffic_Lights_;

public enum TrafficLight {
  RED,
    GREEN,
    YELLOW;


}
