package _3_WORKING_WITH_ABSTRACTION_EXERCISE._4_Traffic_Lights_;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        TrafficLight[] trafficLights = Arrays.stream(sc.nextLine().split(" "))
                .map(TrafficLight::valueOf).toArray(TrafficLight[]::new);
        int n = Integer.parseInt(sc.nextLine());
        TrafficLight[] lights = TrafficLight.values();
        String sb = "";

       while (n--  >0){
            for (int i = 0; i < trafficLights.length; i++) {
                int index = (trafficLights[i].ordinal()+1) % lights.length;
                trafficLights[i] = lights[index];
                sb += trafficLights[i].toString()+" ";

            }
            sb += (System.lineSeparator());

        }
        System.out.println(sb);
    }
}
