package hero;

public class DarkKnight extends Knight {
    public DarkKnight (String name, int level){
        super(name,level);
    }
}
