package hero;

public class Main {
    public static void main(String[] args) {

        BladeKnight blade = new BladeKnight("blade", 12);
        System.out.println(blade);

    }
}
