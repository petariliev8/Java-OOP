package hero;

public class Wizard extends Hero {
    public Wizard (String name, int level){
        super(name,level);
    }
}
