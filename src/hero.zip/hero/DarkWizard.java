package hero;

public class DarkWizard extends Wizard {
    public DarkWizard (String name, int level){
        super(name,level);
    }
}
