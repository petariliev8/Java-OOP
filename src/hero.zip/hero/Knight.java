package hero;

public class Knight  extends Hero{
    public Knight (String name, int level){
        super(name,level);
    }
}
