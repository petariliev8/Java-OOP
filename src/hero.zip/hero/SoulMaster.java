package hero;

public class SoulMaster extends DarkWizard {
    public SoulMaster (String name, int level){
        super(name,level);
    }
}
