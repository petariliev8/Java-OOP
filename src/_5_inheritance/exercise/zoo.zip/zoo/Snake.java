package _5_inheritance.exercise.zoo;

public class Snake extends Reptile {

    protected Snake (String name){
        super(name);
    }

}
