package _5_inheritance.exercise.zoo;

public class Gorilla extends Mammal {
    protected Gorilla(String name){
        super(name);
    }
}
