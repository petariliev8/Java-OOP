package _5_inheritance.exercise.zoo;

public class Lizard extends Reptile {

    protected Lizard(String name){
        super(name);
    }
}
