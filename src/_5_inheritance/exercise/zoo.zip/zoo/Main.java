package _5_inheritance.exercise.zoo;

public class Main {
    public static void main(String[] args) {



    }
}
