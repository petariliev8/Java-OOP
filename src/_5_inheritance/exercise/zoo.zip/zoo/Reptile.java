package _5_inheritance.exercise.zoo;

public class Reptile extends Animal {

    protected Reptile(String name){
        super(name);
    }
}
