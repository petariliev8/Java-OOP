package _5_inheritance;

public class Animal {
   public static void eat(){
       System.out.println("eating...");
   }
}
