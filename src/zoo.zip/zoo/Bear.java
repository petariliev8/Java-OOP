package zoo;

public class Bear extends Mammal {

    protected Bear(String name){
        super(name);
    }
}
