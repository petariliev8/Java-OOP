package zoo;

public class Mammal extends Animal {

    protected Mammal(String name){
        super(name);
    }
}
