package _3_WORKING_WITH_ABSTRACTION_.Hotel_Reservation;

public class PriceCalculator {
    private double perDay;
    private int days;
    private String season;
    private String discountType;


    public  PriceCalculator(){
    }

    public void calculate (double perDay, int days
            , String  season, String discountType){
        double price = perDay*days;
        price =  dependsFromTheSeason(price, season);
        price =  discount(price,discountType);
        System.out.printf("%.2f",price);

    }

    private double discount(double price, String discountType) {
                switch (discountType){
                    case "VIP":
                    price = price*0.8;
                        break;
                    case "SecondVisit":
                        price = price*0.9;
                        break;
                    case "None":
                    price = price;
                        break;
                }
                return price;
    }

    private double dependsFromTheSeason(double price, String season) {
            switch (season){
                case "Autumn":
                    price *= 1;
                    break;
                case "Spring":
                    price *= 2;
                    break;
                case "Winter":
                    price *= 3;
                    break;
                case "Summer":
                    price *= 4;
                    break;
            }
            return price;
    }


    // public  priceDependsOfTheSeason





}
